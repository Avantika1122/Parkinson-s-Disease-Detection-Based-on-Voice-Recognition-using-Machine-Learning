import PySimpleGUI as sg
import numpy as np
from xgboost import XGBClassifier
from sklearn.preprocessing import MinMaxScaler
import joblib
import pandas as pd
from io import StringIO

# Load your trained XGBoost model and scaler from the local files
model = XGBClassifier(eval_metric='mlogloss')
model.load_model('xgboost_model.model')

scaler = joblib.load('min_max_scaler.pkl')

sg.theme_background_color("MediumOrchid1")
# Define the GUI layout and create the window
layout = [
    [
        sg.Column(
            [
                [sg.Frame(layout=[
                    [sg.Text("Parkinson's Disease Detection", text_color="White",
                             background_color="Black", font=('Helvetica', 30, 'bold'))]
                ], title='', title_color='black', relief=sg.RELIEF_FLAT, element_justification='center', background_color='Black', pad=(0, 0))],
                [sg.Text("Enter Patient Data (comma-separated values):", text_color="Black",
                         background_color='MediumOrchid1', font=('Helvetica', 16), pad=(40, 20))],
                [sg.Multiline(key="data", size=(100, 8),
                              background_color='#FFE4C4', pad=(10, 10))],
                [sg.Button(("Diagnose"), size=(15, 3), pad=(0, 0), button_color=(
                    'white', '#008CBA'), font=('Helvetica', 16), border_width=5)],
                [sg.Text("", size=(100, 10), key="output", text_color="Black",
                         background_color='LightSkyBlue', font=('Helvetica', 16), pad=(10, 10))]
            ],
            justification='center',
            element_justification='center',
            expand_x=True,
            expand_y=True,
            background_color='MediumOrchid1'
        )
    ]
]
window = sg.Window("Parkinson's Disease Diagnosis", layout, finalize=True)

while True:
    event, values = window.read()

    if event == sg.WIN_CLOSED:
        break
    elif event == "Diagnose":
        try:
            # Extract input data
            input_data = values["data"]

            # Check if input_data is a CSV file path or a single string
            if input_data.strip().endswith('.csv'):
                # Load data from a CSV file
                df = pd.read_csv(input_data)
            else:
                # Load data from a single string
                input_data = StringIO(input_data)
                df = pd.read_csv(input_data, header=None)

            # Standardize the input data using the loaded scaler
            standardized_data = scaler.transform(df)

            # Predict using the loaded model
            predictions = model.predict(standardized_data)

            # Display diagnosis result
            result = [
                "Sample {}: {}".format(i+1, 'Parkinson\'s Disease Detected' if pred == 1 else 'No Parkinson\'s Disease Detected')
                for i, pred in enumerate(predictions)
            ]

            window["output"].update("\n".join(result), text_color="red", font=("Helvetica", 16))
        except Exception as e:
            sg.popup_error("Error: {}".format(str(e)))

window.close()
